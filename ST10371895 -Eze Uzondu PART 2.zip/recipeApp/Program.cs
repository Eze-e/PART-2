﻿

using System;
using System.Collections.Generic;
using System.Linq;
// using System.Reflection.Metadata; , its not relly useful in this part butI will use it in part 3

public class NutritionFact // a CLASS FOR THE CALORIES AND FOOD GROUP OF THE INGREDIENTS 
{
    public int Calories { get; set; }
    public string FoodGroup { get; set; }
}

public class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public List<NutritionFact> NutritionFacts { get; set; }

                               public Ingredient()
    {
        NutritionFacts = new List<NutritionFact>();
    }
}

                               public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> Steps { get; set; }
    public int TotalCalories { get; private set; }

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

                               public void EnterRecipeDetails()
    {
        Console.Write("Enter recipe name: ");  // user will enter the name of the recipe
        Name = Console.ReadLine();

        Console.Write("Enter number of ingredients: ");
        int numIngredients = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            Ingredient ingredient = new Ingredient();
            Console.Write($"Enter ingredient {i + 1} name: ");
            ingredient.Name = Console.ReadLine();
            Console.Write($"Enter ingredient {i + 1} quantity: ");
            ingredient.Quantity = Convert.ToDouble(Console.ReadLine());
            Console.Write($"Enter ingredient {i + 1} unit: ");
            ingredient.Unit = Console.ReadLine();

            Console.Write($"Enter ingredient {i + 1} calorie count: "); //user eneters the calories of each ingredient
            int calorieCount = Convert.ToInt32(Console.ReadLine());
            NutritionFact nutritionFact = new NutritionFact();
            nutritionFact.Calories = calorieCount;
            ingredient.NutritionFacts.Add(nutritionFact);

            Console.Write($"Enter ingredient {i + 1} food group: "); //user enters the food ground of the ingredient 
            string foodGroup = Console.ReadLine();
            nutritionFact.FoodGroup = foodGroup;

            Ingredients.Add(ingredient);


        }

        Console.Write("Enter number of steps: ");
        int stepsAmount = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < stepsAmount; i++)
        {
            Console.Write($"Enter step {i + 1}: ");
            string step = Console.ReadLine();
            Steps.Add(step);
        }
    }

                               public void CalculateTotalCalories() //calculates the calory count of the recipe
    {
        TotalCalories = Ingredients.Sum(ingredient => ingredient.NutritionFacts.Sum(nutritionFact => nutritionFact.Calories));
    }

                               public void ShowRecipe()
    {
        CalculateTotalCalories(); // Calculate the total calories before displaying the recipe to the user

        Console.WriteLine($"Recipe: {Name}");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine($"  {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            foreach (var nutritionFact in ingredient.NutritionFacts)
            {
                Console.WriteLine($"    Calories: {nutritionFact.Calories}, Food Group: {nutritionFact.FoodGroup}");// lists the calories and food group of each ingredient in the EnterRecipeDetails class
            }
        }
        Console.WriteLine($"\nTotal Calories: {TotalCalories}");

        if (TotalCalories > 300)
        {
            Console.WriteLine("Warning: This recipe exceeds 300 calories."); // output if the total amount of calories exceeds 300
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {Steps[i]}");
        }
    }

                               public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }
    public void Reset()
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity = 1;
        }
    }

    public void DeleteData()
    {
        Ingredients.Clear();
        Steps.Clear();
    }
}

class Program
{
    static List<Recipe> recipes = new List<Recipe>();

    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("\nRecipeManagement System");

            Console.WriteLine("1. Enter Recipe");

            Console.WriteLine("2. Show Recipe");

            Console.WriteLine("3. Display Recipes in Alphabetical Order"); //part 2
            
            Console.WriteLine("4. Exit");

            Console.WriteLine("5. Show Recipe from  recipe list by NUMBER"); //part 2

            Console.WriteLine("6. Scale the Recipe");

            Console.WriteLine("7. Reset the Quantities");

            Console.WriteLine("8. Delete Data");

            Console.Write("Enter choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Recipe newRecipe = new Recipe();
                    newRecipe.EnterRecipeDetails();
                    recipes.Add(newRecipe);
                    break;
                case 2:
                    Console.Write("Enter recipe number: ");
                    int recipeNum = Convert.ToInt32(Console.ReadLine());
                    if (recipeNum > 0 && recipeNum <= recipes.Count)
                    {
                        recipes[recipeNum - 1].ShowRecipe();
                    }
                    else
                    {
                        Console.WriteLine("Recipe number not found.");
                    }
                    break;
                case 3://part 2
                    DisplayRecipesInAlphabeticalOrder();
                    break;
                case 4:
                    Environment.Exit(0);
                    break;
                case 5: // part 2
                    DisplayRecipeByNumber();
                    break;
                case 6:
                    if (recipes.Count > 0)
                    {
                        Console.Write("Enter recipe number to scale: ");
                        int scaleRecipeNum = Convert.ToInt32(Console.ReadLine());
                        if (scaleRecipeNum > 0 && scaleRecipeNum <= recipes.Count)
                        {
                            Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                            double factor = Convert.ToDouble(Console.ReadLine());
                            recipes[scaleRecipeNum - 1].ScaleRecipe(factor);
                        }
                        else
                        {
                            Console.WriteLine("Recipe number not found.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No recipes available to scale.");
                    }

                    break;
                case 7:
                    Console.Write("Enter the recipe number to reset: ");
                    int resetRecipeNumber = Convert.ToInt32(Console.ReadLine()) - 1;
                    recipes[resetRecipeNumber].Reset();
                    break;
                case 8:
                    Console.Write("Enter the recipe number to delete: ");
                    int deleteRecipeNumber = Convert.ToInt32(Console.ReadLine()) - 1;
                    recipes[deleteRecipeNumber].DeleteData();
                    recipes.RemoveAt(deleteRecipeNumber);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please enter 1, 2, 3, 4, or 5.");
                    break;
            }
        }
    }
    // This method sorts the recipes from the input of the user in alphabetical order using the first letter of the recipe name
                 static void DisplayRecipesInAlphabeticalOrder()
    {
        var sortedRecipes = recipes.OrderBy(r => r.Name);
        Console.WriteLine("\nRecipes in alphabetical order:");
        foreach (var recipe in sortedRecipes)
        {
            Console.WriteLine($"{recipes.IndexOf(recipe) + 1}. {recipe.Name}");
        }
    }
    //this method allows the user to choose a recipe from the list of rcipes after they have been ordered alphabetically and display a desired recipe using a numbering system.
                 static void DisplayRecipeByNumber()
    {
        var sortedRecipes = recipes.OrderBy(r => r.Name);
        Console.WriteLine("\nRecipe List  in alphabetical order:"); // list the availablle recipes ,for user to choose from
        foreach (var recipe in sortedRecipes)
        {
            Console.WriteLine($"{recipes.IndexOf(recipe) + 1}. {recipe.Name}");
        }

        Console.Write("Enter recipe number: ");
        int recipeNum = Convert.ToInt32(Console.ReadLine());

        if (recipeNum > 0 && recipeNum <= recipes.Count)
        {
            recipes[recipeNum - 1].ShowRecipe();
        }
        else
        {
            Console.WriteLine("Recipe number not found.");
        }
    }
}



[TestClass]
public class RecipeTest
{
    [TestMethod]
    public void TestTotalCalories()
    {
        e
        Recipe recipe = new Recipe();
        recipe.Ingredients = new List<Ingredient>
        {
            new Ingredient { Name = "Ingredient1", Quantity = 100, NutritionFacts = new List<NutritionFact> { new NutritionFact { Calories = 10 } } },
            new Ingredient { Name = "Ingredient2", Quantity = 200, NutritionFacts = new List<NutritionFact> { new NutritionFact { Calories = 5 } } }
        };


        recipe.CalculateTotalCalories();